# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 11:14:50 2024

@author: Karol Diaz
"""

import numpy as np
import serial
import time
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt

# Función para aplicar un filtro pasa altas y pasa bajas
def butter_bandpass_filter(data, lowcut, highcut, fs, order=4):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    y = filtfilt(b, a, data)
    return y

# Configuración del puerto serial
arduino = serial.Serial('COM5', 9600, timeout=1)
time.sleep(2)

# Variables para almacenar los datos
data = []

# Leer datos del Arduino
try:
    for _ in range(500):  # Leer 500 muestras
        line = arduino.readline().decode('utf-8').strip()
        if line.isdigit():
            data.append(int(line))
finally:
    arduino.close()

# Filtros según los valores típicos de EMG (ajusta las frecuencias según sea necesario)
fs = 1000  # Frecuencia de muestreo (ajusta según tu configuración)
lowcut = 20.0  # Frecuencia de corte inferior (pasa altas)
highcut = 450.0  # Frecuencia de corte superior (pasa bajas)

# Aplicar el filtro pasa banda
filtered_data = butter_bandpass_filter(data, lowcut, highcut, fs)

# Graficar los resultados
plt.plot(filtered_data)
plt.title('Señal EMG Filtrada')
plt.xlabel('Muestras')
plt.ylabel('Valor Filtrado')
plt.show()

# Crear una ventana de Hanning para dividir la señal en segmentos
window_size = 256  # Tamaño de la ventana
window = np.hanning(window_size)

# Aplicar la ventana y realizar un análisis espectral
for i in range(0, len(filtered_data) - window_size, window_size):
    segment = filtered_data[i:i + window_size] * window
    plt.plot(segment)
    plt.title('Segmento de señal con ventana de Hanning')
    plt.show()

from scipy.fft import fft

# Calcular la FFT para cada segmento
for i in range(0, len(filtered_data) - window_size, window_size):
    segment = filtered_data[i:i + window_size] * window
    spectrum = np.abs(fft(segment))
    
    # Graficar el espectro de frecuencias
    plt.plot(spectrum)
    plt.title('Espectro de frecuencias de la señal EMG')
    plt.xlabel('Frecuencia (Hz)')
    plt.ylabel('Amplitud')
    plt.show()

# Calcular la frecuencia mediana en cada ventana
freq_median = np.median(spectrum)
print(f"Frecuencia mediana: {freq_median} Hz")
